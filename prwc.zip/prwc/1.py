import csv
import json

# Читаем CSV файл
with open('animals.csv', mode='r', encoding='utf-8') as csv_file:
    csv_reader = csv.DictReader(csv_file)
    data = [row for row in csv_reader]  # Список словарей

# Сохраняем в JSON файл
with open('zoo.json', mode='w', encoding='utf-8') as json_file:
    json.dump(data, json_file, ensure_ascii=False, indent=4)

print("Данные успешно преобразованы и сохранены в zoo.json")