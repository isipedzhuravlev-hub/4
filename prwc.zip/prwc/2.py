import csv

# Словарь с зарплатами по должностям
salary_map = {
    'Разработчик': 120000,
    'Менеджер': 100000,
    'Дизайнер': 90000
}

# Чтение исходного файла и запись нового
with open('csv_file.csv', mode='r', encoding='utf-8', newline='') as infile, \
     open('money.csv', mode='w', encoding='utf-8', newline='') as outfile:

    reader = csv.DictReader(infile)
    
    # Проверяем ожидаемые заголовки 
    expected_fields = ['Имя', 'Возраст', 'Город', 'Должность']
    if reader.fieldnames != expected_fields:
        print(f"Предупреждение: заголовки файла: {reader.fieldnames}")
    
    # Новый список заголовков с добавленной Зарплатой
    new_fieldnames = reader.fieldnames + ['Зарплата']
    
    writer = csv.DictWriter(outfile, fieldnames=new_fieldnames)
    writer.writeheader()  # Записываем заголовок один раз
    
    # Обработка строк
    for row in reader:
        position = row['Должность'].strip()  # На случай лишних пробелов
        row['Зарплата'] = salary_map.get(position, 0)  # 0 для неизвестных должностей
        writer.writerow(row)

print("Файл money.csv успешно создан!")